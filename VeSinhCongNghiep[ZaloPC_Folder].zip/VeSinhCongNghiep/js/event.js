function myMap() {
var mapProp= {
  center:new google.maps.LatLng(51.508742,-0.120850),
  zoom:5,
};
var map = new google.maps.Map(document.getElementById("googleMap"),mapProp);
}

function openMenu() {
  var x = document.getElementById("myTopnav");
  if (x.className === "topnav") {
    x.className += " responsive";
  } else {
    x.className = "topnav";
  }
}


function loadService(imgs) {
  var expandImg = document.getElementById("expandedImg");
  var imgText = document.getElementById("imgtext");
  expandImg.src = imgs.src;
  imgText.innerHTML = imgs.alt;
  expandImg.parentElement.style.display = "block";
}
var img1 = {
  src: "./img/new-3.jpg",
  alt: "Dịch vụ vệ sinh văn phòng là một trong những mối quan tâm hàng đầu của các doanh nghiệp."
}
var img2 = {
  src: "./img/new-2.jpg",
  alt: "Vệ sinh công trình sau xây dựng đang dần được nhiều người tin dùng hơn bởi mức độ hoạt động hiệu quả cũng như ít tốn kém thời gian và chi phí thực hiện"
}
var img3 = {
  src: "./img/giat-ghe-sofa.png",
  alt: "Giặt thảm đúng cách giúp duy trì màu sắc thảm và làm sạch cho thảm. Giặt ghế sofa với cam kết giá rẻ nhất, giặt sạch nhất."
}
var img4 = {
  src: "./img/tt-6.jpg",
  alt: "Dịch vụ vệ sinh nhà cửa, tẩy nấm mốc mang lại không gian sạch sẽ, thoải mái nhất cho ngôi nhà của bạn."
}